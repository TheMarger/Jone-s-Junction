package main;

public class completion {

	public static void main(String[] args) {
		
		
		System.out.println("You have escaped.");
		
		//Credits
	}
	
}
